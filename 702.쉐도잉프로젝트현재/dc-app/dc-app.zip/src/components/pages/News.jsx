// 뉴스페이지 메인컨텐츠

import { Banner } from "../modules/Banner";

export function News(){
    return(
        <>
            <Banner category="NEWS" />
        </>
    )

} ////////////  News 컴포넌트 ///////////