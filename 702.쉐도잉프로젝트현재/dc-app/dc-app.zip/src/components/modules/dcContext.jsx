import { createContext } from "react";

// DC PJ - Context API 
export const dcCon = createContext();